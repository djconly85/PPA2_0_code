import sys
import os 
import time 
import datetime 
import arcpy 

def trace():
    import traceback, inspect
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    # script name + line number
    line = tbinfo.split(", ")[1]
    filename = inspect.getfile(inspect.currentframe())
    # Get Python syntax error
    synerror = traceback.format_exc().splitlines()[-1]
    return line, filename, synerror


if(__name__=='__main__'):
    #D:\ProjectsUtils\HydroProjects\ApUtilityTools\Toolboxes\AH2020.tbx\AH20202011_MSG
    where = arcpy.GetParameterAsText(0)
    my_layer = arcpy.GetParameterAsText(1)
    arcpy.env.overwriteOutput = True
    try:
        return_msg = "where = {} {}".format(where, datetime.datetime.now())
        my_fl = "fl{}".format(int(time.clock()))
        if(arcpy.Exists(my_fl)): arcpy.Delete_management(my_fl)
        arcpy.MakeFeatureLayer_management(my_layer, my_fl)
        arcpy.SelectLayerByAttribute_management(my_fl, "NEW_SELECTION", where) 
        c = "out{}".format(int(time.clock()))
        c_out = os.path.join(arcpy.env.scratchGDB, c) 
        if(arcpy.Exists(c_out)): arcpy.Delete_management(c_out)
        arcpy.CopyFeatures_management(my_fl, c_out) 
        c_out_layer = "out_layer{}".format(int(time.clock()))
        if(arcpy.Exists(c_out_layer)): arcpy.Delete_management(c_out_layer)
        arcpy.MakeFeatureLayer_management(c_out, c_out_layer)
        arcpy.SetParameterAsText(2, c_out_layer)
    except:
        arcpy.AddMessage(trace())
        arcpy.AddError(trace())

    #arcpy.SetParameterAsText(1, return_msg)


