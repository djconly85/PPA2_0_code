import sys 
import time 
import datetime 
import arcpy 

def trace():
    import traceback, inspect
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    # script name + line number
    line = tbinfo.split(", ")[1]
    filename = inspect.getfile(inspect.currentframe())
    # Get Python syntax error
    synerror = traceback.format_exc().splitlines()[-1]
    return line, filename, synerror


if(__name__=='__main__'):
    #D:\ProjectsUtils\HydroProjects\ApUtilityTools\Toolboxes\AH2020.tbx\AH20202011_MSG
    msg = arcpy.GetParameterAsText(0)
    try:
        return_msg = "{} {}".format(msg, datetime.datetime.now())
        arcpy.AddMessage(return_msg)
    except:
        arcpy.AddMessage(trace())
        arcpy.AddError(trace())

    arcpy.AddMessage("here")
    arcpy.SetParameterAsText(1, return_msg)

