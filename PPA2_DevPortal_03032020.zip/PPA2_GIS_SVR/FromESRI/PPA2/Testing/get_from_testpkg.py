# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

v2 = 'test_var'