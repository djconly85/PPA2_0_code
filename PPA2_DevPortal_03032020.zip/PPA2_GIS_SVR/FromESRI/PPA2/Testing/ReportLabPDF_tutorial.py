# -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 13:13:38 2020

@author: dconly

https://www.reportlab.com/documentation/tutorial/#json-to-pdf-invoice-tutorial
"""

